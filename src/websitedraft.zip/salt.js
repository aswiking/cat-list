function salt_init () {
	$(".salt-logo-container").mouseover(salt_flageffect);
	$("#internationaltoggle").click(salt_toggleinternational);
}
function salt_toggleinternational () {
	$(".salt-international").toggleClass("salt-hidden");
}
function salt_flageffect (e) {
	if (Math.random() > 0.8) {
		$(this).addClass("salt-pride");
	} else {
		$(this).removeClass("salt-pride");
	}
}
$(document).ready(salt_init);
